Synthetic long-path reference.
