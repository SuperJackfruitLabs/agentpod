// The suite theme logic, written once. theme.ts wraps it for the browser client; SuiteHead.astro
// inlines this same text (with `export` stripped) into the head script so the first paint is
// already themed. Keep it dependency-free and tiny: it ships on every page.
//
// Storage note: the suite preference lives in localStorage ('sjl-theme-pref') per origin and is
// carried to the next product as '#sjl-theme=<pref>'. We deliberately do not use vibekit's
// appearance cookie here: the six products are on different domains, so a cookie cannot be shared.

export const PREF_KEY = 'sjl-theme-pref';
const FRAGMENT = /^#sjl-theme=(system|light|dark)$/;

export function parsePref(v) {
  return v === 'light' || v === 'dark' ? v : 'system';
}

/** The carried preference if `hash` is exactly '#sjl-theme=…', else null. Never touches other hashes. */
export function matchFragment(hash) {
  const m = FRAGMENT.exec(hash);
  return m ? m[1] : null;
}

/**
 * env: { site: { key, values: { light, dark } }, read(k), write(k, v|null), systemLight(): boolean,
 *        paint(siteValue, effective: 'light'|'dark') }
 */
export function createTheme(env) {
  let pref = parsePref(env.read(PREF_KEY));
  const effective = () => (pref === 'system' ? (env.systemLight() ? 'light' : 'dark') : pref);
  function apply() {
    const t = effective();
    env.write(PREF_KEY, pref);
    env.write(env.site.key, pref === 'system' ? null : env.site.values[pref]);
    env.paint(env.site.values[t], t);
  }
  return {
    get: () => pref,
    effective,
    apply,
    set(p) { pref = parsePref(p); apply(); },
    carry: () => '#sjl-theme=' + pref,
  };
}
