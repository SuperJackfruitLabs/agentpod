# vibekit

One design for every Super Jackfruit Labs product.

People choose a **vibe** (Daylight, Paper, Studio or Quiet). It sets how every product looks
and how its screens are laid out, in light and dark, with a room that follows the sun.

## Use it

See [docs/usage.md](docs/usage.md). Without Svelte (a server-rendered app such as Accounts): [docs/non-svelte.md](docs/non-svelte.md). Motion: [docs/motion.md](docs/motion.md). Agents: [static/llms.txt](static/llms.txt).

## Work on it

Scripts need Node 22.

```sh
corepack enable && pnpm install
pnpm dev          # the gallery at http://localhost:5173
pnpm tokens       # after editing tokens/source
pnpm verify       # everything CI checks
pnpm test:e2e     # screenshots, aria snapshots and axe
pnpm test:phone   # the phone-width suite (runs in CI)
pnpm storybook       # every component in every vibe, theme and accent, at http://localhost:6006
pnpm references      # rebuild the reference sheets from references/src (committed)
pnpm references:lock # record new sheets in references.lock; a changed sheet needs --allow <Component|pixels|sheet>
pnpm references:check # rebuild the sheets and fail if references/components differs from what is committed
pnpm test:stories    # each story's play function and its axe check, in Chromium
pnpm test:pixels     # each component's story against its reference sheets, 8 looks each (both sides rendered live; runs in CI)
```

Design sources: [design/mockups/](design/mockups/README.md) (open `design/mockups/index.html`); the Accounts artboards are in [design/mockups/accounts/](design/mockups/accounts/README.md).

Colours are edited only in `tokens/source/*.ts`, as hex. `tokens/dtcg` and `src/lib/styles/tokens.css` are generated, and are committed so changes are reviewable.

**Start here:** [the vibes design spec](docs/specs/2026-10-11-vibes-design.md).
