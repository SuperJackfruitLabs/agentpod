// Captain Jack, the lab's guide (ported from the prototype's frame.js openJack/ask): a sheet in
// its own shadow root, so a site's CSS cannot reach it. Answers stream from the suite worker as
// SSE (`event: facts`, data chunks, `event: done`); sources become numbered footnotes, a cited
// limited claim adds "The lab's fine print", and the sources are listed under the answer.
// He is drawn by the delivered rig, loaded only when the sheet opens or the Ask field gets
// focus; until then (and without JS) the static art stands in.
import tokens from '../components/styles/tokens.css?raw';
import css from '../components/styles/jack.css?raw';
import { PRODUCTS, type Slug } from '../data/products';
import type { JackState, Rig } from './jack-rig';

/** Same-origin: the suite worker is routed at /captain/* on every product's domain. */
export const JACK_URL = '/captain/';

const GREET: Record<Slug, string> = {
  supermessage: "This is SuperMessage. It's early: a Matrix client where agents sit in the room as participants. Ask me what works today.",
  superpipeline: 'This is SuperPipeline, the board agents pull work from. People keep the gates. Ask me how a card moves.',
  superlibrary: 'This is SuperLibrary. It keeps what agents make, labelled with how it turned out. Ask me what it stores.',
  superwitness: 'This is SuperWitness. It keeps runs on the record and lets you grade them. Ask me what a run document is.',
  agentpod: 'This is AgentPod, a console for the machines agents live on. You host all of it. Ask me which harnesses it knows.',
  salaam: "This is Salaam, the lab's agent harness: a persistent home for agent sessions. Ask me what survives a closed terminal.",
};
const SUGGEST: Record<Slug, string[]> = {
  supermessage: ['Can I use it on iOS?', 'Is it encrypted?', 'Can I approve agent requests from chat?'],
  superpipeline: ['How do agents connect?', 'What is a gate?', 'Is there a CLI?'],
  superlibrary: ['What does it store?', 'How does search rank things?', 'Can my agent read it over MCP?'],
  superwitness: ['What is a run document?', 'Can I use it without the other products?', 'Does it store telemetry itself?'],
  agentpod: ['Which harnesses does it support?', 'Where can it provision machines?', 'Do I need to open ports?'],
  salaam: ['What survives a closed terminal?', 'Which harnesses can it run?', 'How do approvals work?'],
};
const DONT_KNOW = /I don't know that one/;

interface Fact { id: string; title: string; product: string; status: string; caveat: string | null; href?: string }

const esc = (s: string): string => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]!);

// Only the products' docs and the lab's own site become links; any other URL stays text.
const LINK_HOSTS = new Set(['superjackfruit.com', ...Object.values(PRODUCTS).map((p) => new URL(p.docs).hostname)]);
const linkable = (u: string): boolean => { try { const x = new URL(u); return x.protocol === 'https:' && !x.username && !x.password && LINK_HOSTS.has(x.hostname); } catch { return false; } };

/** Sources show as numbered footnotes in order of first use; the ids are bookkeeping. */
export const cite = (t: string, order: string[]): string => t.replace(/[&<]/g, (c) => (c === '&' ? '&amp;' : '&lt;'))
  .replace(/\s*\[([A-Z]+-\d+|D\d+)\]/g, (_, id: string) => {
    if (!order.includes(id)) order.push(id);
    return `<sup class="fn">${order.indexOf(id) + 1}</sup>`;
  })
  .replace(/\s*\[[A-Z]*\]/g, '').replace(/`([^`\n]+)`/g, '<code>$1</code>')
  .replace(/(^|[\s(])(https:\/\/[^\s<"]+[^\s<".,;:)])/g, (all, pre: string, u: string) => (linkable(u) ? `${pre}<a href="${u}" target="_blank" rel="noopener noreferrer">${u}</a>` : all)).replace(/\*\*([^*]+)\*\*/g, '$1');

const store = {
  get(k: string): string | null { try { return localStorage.getItem(k); } catch { return null; } },
  set(k: string, v: string): void { try { localStorage.setItem(k, v); } catch { /* private mode */ } },
};
const visitorId = (): string => {
  const id = store.get('sjl-visitor');
  if (id) return id;
  const fresh = crypto.randomUUID();
  store.set('sjl-visitor', fresh);
  return fresh;
};

export interface JackOpts { product: Slug; jackUrl?: string; headRoot?: ShadowRoot | null }
export interface Jack { open(question?: string): void; close(): void }

export function mountJack(opts: JackOpts): Jack {
  const me = PRODUCTS[opts.product];
  const head = opts.headRoot ?? null;
  const askField = head?.getElementById('askj') as HTMLElement | null;
  const staticArt = head?.querySelector('#askj svg.jack')?.outerHTML ?? '';
  const agent = new URL(`agents/captain-jack/${visitorId()}`, new URL(opts.jackUrl ?? JACK_URL, location.href));

  const host = document.createElement('sjl-captain-jack');
  host.dataset.product = me.slug;
  const root = host.attachShadow({ mode: 'open' });
  const onC = me.slug === 'superpipeline' ? '#2c2a26' : '#fff';
  root.innerHTML = `<style>${tokens}:host{--sjl-c:${me.color};--sjl-c-hi:${me.hi};--sjl-on-c:${onC}}${css}</style>
<div class="panel" id="panel" role="dialog" aria-label="Captain Jack"><div class="ph"><div class="face" id="face">${staticArt}<div class="rig" id="rig"></div></div><div><b>Captain Jack</b><small>The lab's guide. A character; an AI writes my answers.</small></div><button id="close" type="button" aria-label="Close">✕</button></div>
<div class="log" id="log" aria-live="polite"></div><div class="sugg" id="sugg"></div>
<form id="f"><input id="q" placeholder="Ask about ${esc(me.name)}, or any product…" autocomplete="off" maxlength="500" aria-label="Your question"><button>Ask</button></form>
<div class="disc">I read the product docs first, and check them against the lab's claims ledger. If neither says it, I'll tell you.</div></div>
<button class="sel" id="sel" type="button">${staticArt}Ask Captain Jack about this</button>`;
  // Theme-aware like the other frame hosts: follow <html data-sjl-theme>.
  const theme = () => { const t = document.documentElement.dataset.sjlTheme; if (t) host.setAttribute('data-sjl-theme', t); };
  theme();
  new MutationObserver(theme).observe(document.documentElement, { attributes: true, attributeFilter: ['data-sjl-theme'] });
  document.body.append(host);

  const $ = <T extends HTMLElement>(id: string) => root.getElementById(id) as T;
  const panel = $('panel'), log = $('log'), sugg = $('sugg'), input = $<HTMLInputElement>('q'), face = $('face');
  const isOpen = () => panel.classList.contains('on');

  // ---- the rig: loaded lazily, mounted while the sheet is open, destroyed on close ----
  let rigModule: Promise<typeof import('./jack-rig')> | null = null;
  const loadRig = () => (rigModule ??= import('./jack-rig').then(async (m) => { await m.loadRig(); return m; }).catch((e) => { rigModule = null; throw e; }));
  let rig: Rig | null = null;
  let state: JackState = 'idle';
  let quiet: ReturnType<typeof setTimeout> | undefined;
  const setState = (s: JackState) => {
    state = s;
    host.dataset.jackState = s;
    try { rig?.setState(s); } catch { /* the static art stays */ }
  };
  const speak = (chunk: string) => {
    if (!rig) return;
    // Mouth driven by the token cadence: a level per chunk, silence when the stream pauses.
    try { rig.setSpeechLevel(Math.min(1, 0.35 + chunk.length / 12)); } catch { return; }
    clearTimeout(quiet);
    quiet = setTimeout(() => { try { rig?.setSpeechLevel(0); } catch { /* destroyed */ } }, 140);
  };
  const mountTheRig = () => loadRig().then(async (m) => {
    if (!isOpen() || rig) return;
    if (!root.getElementById('rig-css')) { const st = document.createElement('style'); st.id = 'rig-css'; st.textContent = m.rigCss; root.prepend(st); }
    rig = await m.mountRig($('rig'), state);
    face.classList.add('rigged');
  }).catch((e) => console.warn('[sjl-frame] Captain Jack rig', e)); // the static art stays
  askField?.addEventListener('focus', () => void loadRig().catch(() => {}), { once: true });

  // ---- conversation ----
  const say = (text: string, who: 'u' | 'j') => {
    const m = document.createElement('div');
    m.className = `m ${who}`;
    m.textContent = text;
    log.append(m);
    log.scrollTop = log.scrollHeight;
    return m;
  };
  let busy = false;
  async function ask(question: string): Promise<void> {
    if (busy || !question.trim()) return;
    busy = true;
    say(question, 'u');
    sugg.innerHTML = '';
    const m = say('…', 'j');
    setState('thinking');
    let text = '';
    let end: JackState = 'idle';
    let waitingReply = false;
    try {
      const r = await fetch(agent, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ message: question.slice(0, 500), product: me.slug }) });
      if (!r.ok || !r.body) throw new Error(`HTTP ${r.status}`);
      const reader = r.body.getReader(), dec = new TextDecoder();
      let buf = '', facts: Fact[] = [];
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n\n')) >= 0) {
          const ev = buf.slice(0, i); buf = buf.slice(i + 2);
          const kind = ev.match(/^event: (\w+)/m)?.[1], data = ev.match(/^data: (.*)$/m)?.[1];
          if (kind === 'facts' && data) facts = JSON.parse(data);
          // A limit reply (break for today, asked plenty, catch his breath): he waits.
          else if (kind === 'state' && data) waitingReply = JSON.parse(data) === 'waiting';
          else if (!kind && data) {
            const chunk = JSON.parse(data) as string;
            text += chunk;
            if (state !== 'speaking') setState('speaking');
            speak(chunk);
            m.innerHTML = cite(text, []);
            log.scrollTop = log.scrollHeight;
          }
        }
      }
      const order: string[] = [];
      m.innerHTML = cite(text, order);
      const used = order.map((id) => facts.find((f) => f.id === id)).filter((f): f is Fact => !!f);
      const lim = used.filter((f) => f.status === 'limited' && f.caveat);
      if (lim.length) m.insertAdjacentHTML('beforeend', `<details class="fine"><summary>The lab's fine print</summary>${lim.map((f) => `<p>${esc(f.caveat!.replace(/\s*\((?:[A-Z]+-\d+(?:,\s*)?)+\)/g, '').replace(/\*\*/g, ''))}</p>`).join('')}</details>`);
      if (used.length) m.insertAdjacentHTML('beforeend', `<ol class="srcs">${used.map((f) => f.status === 'docs'
        ? `<li><a href="${esc(f.href ?? '')}" target="_blank" rel="noopener">${esc(PRODUCTS[f.product as Slug]?.name ?? '')} docs · ${esc(f.title)}</a></li>`
        : `<li>Checked by the lab · ${esc(f.title)} <em>${f.status === 'verified' ? 'confirmed' : 'true, with a note'}</em></li>`).join('')}</ol>`);
      end = waitingReply ? 'waiting' : DONT_KNOW.test(text) ? 'attention' : used.length ? 'success' : 'idle';
    } catch {
      m.textContent = `I can't reach my notes right now. The docs are the better source: ${me.docs}`;
      end = 'attention';
    }
    clearTimeout(quiet);
    try { rig?.setSpeechLevel(null); } catch { /* destroyed */ }
    setState(end);
    busy = false;
  }

  function open(question?: string): void {
    head?.getElementById('hint')?.classList.remove('on');
    if (!isOpen()) {
      panel.classList.add('on');
      if (!busy) setState('idle');
      void mountTheRig();
    }
    if (!log.childElementCount) {
      say(`I'm Captain Jack, the lab's guide. I'm a character, and an AI writes my answers. ${GREET[me.slug]}`, 'j');
      sugg.innerHTML = SUGGEST[me.slug].map((s) => `<button type="button">${esc(s)}</button>`).join('');
      sugg.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => void ask(b.textContent ?? '')));
    }
    if (question) void ask(question);
    setTimeout(() => input.focus(), 50);
  }
  function close(): void {
    if (!isOpen()) return;
    panel.classList.remove('on');
    clearTimeout(quiet);
    try { rig?.destroy(); } catch { /* already gone */ }
    rig = null;
    face.classList.remove('rigged');
    askField?.focus();
  }

  input.addEventListener('input', () => { if (!busy) setState(input.value.trim() ? 'listening' : 'idle'); });
  $('f').addEventListener('submit', (e) => { e.preventDefault(); const q = input.value; input.value = ''; void ask(q); });
  $('close').addEventListener('click', close);
  addEventListener('keydown', (e) => { if (e.key === 'Escape' && isOpen()) close(); });
  addEventListener('sjl-ask', (e) => open((e as CustomEvent<{ question?: string }>).detail?.question));

  // He says hello once per site, after you've had a moment to look around.
  // Not if you came here from another suite site: he has already said hello there.
  const hint = head?.getElementById('hint');
  const fromSuite = /(^|\.)(superjackfruit\.com|superlibrary\.dev|superwitness\.dev|superpipeline\.dev|agentpod\.dev|salaam\.sh|supermessage\.dev)$/;
  let referrer = '';
  try { referrer = new URL(document.referrer).hostname; } catch { /* no referrer */ }
  const met = store.get(`sjl-greeted-${me.slug}`) || (referrer !== location.hostname && fromSuite.test(referrer));
  if (hint && !met) setTimeout(() => {
    if (isOpen()) return;
    hint.innerHTML = `<span class="who"><b>Captain Jack</b> · the lab's guide</span>${esc(GREET[me.slug])}<span class="acts"><button id="yes" type="button">Ask Captain Jack</button><button class="no" id="no" type="button">Not now</button></span>`;
    hint.classList.add('on');
    const hide = (): void => { hint.classList.remove('on'); removeEventListener('scroll', onScroll); };
    const y0 = scrollY, onScroll = (): void => { if (Math.abs(scrollY - y0) > 240) hide(); };
    addEventListener('scroll', onScroll, { passive: true });
    setTimeout(hide, 15000);
    head!.getElementById('yes')?.addEventListener('click', () => { hide(); open(); });
    head!.getElementById('no')?.addEventListener('click', hide);
    store.set(`sjl-greeted-${me.slug}`, '1');
  }, 8000);

  // Select any text on the page and ask him about it.
  const sel = $<HTMLButtonElement>('sel');
  let selected = '';
  document.addEventListener('mouseup', () => setTimeout(() => {
    const s = getSelection(), t = s?.toString().trim() ?? '';
    if (!s || t.length < 4 || t.length > 300 || s.rangeCount === 0) { sel.classList.remove('on'); return; }
    const r = s.getRangeAt(0).getBoundingClientRect();
    sel.style.left = `${r.left + scrollX}px`;
    sel.style.top = `${r.bottom + scrollY + 8}px`;
    selected = t;
    sel.classList.add('on');
  }, 10));
  sel.addEventListener('click', () => { sel.classList.remove('on'); open(`On this page it says: "${selected}". What does that mean, and is it true today?`); });

  return { open, close };
}
