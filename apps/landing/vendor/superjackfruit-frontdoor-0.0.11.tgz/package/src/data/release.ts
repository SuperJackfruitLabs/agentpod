import snapshot from './ledger.snapshot.json';
import { PRODUCTS, type Slug } from './products';

export interface Release { tag: string; url: string; published_at?: string | null }

/** The suite worker's releases endpoint on a product's own site (see worker/src/releases.ts). */
export const releasesUrl = (slug: Slug, origin?: string): string => `${origin ?? PRODUCTS[slug].url}/captain/releases/${slug}`;

const TIMEOUT_MS = 3000;
const env = (k: string): string | undefined => (typeof process !== 'undefined' ? process.env?.[k] : undefined) || undefined;
const valid = (tag: unknown, url: unknown): boolean => typeof tag === 'string' && /^v?\d/.test(tag) && typeof url === 'string' && url.startsWith('https://');

export interface ReleaseOpts {
  fetch?: typeof fetch;
  /** Where to find /captain/releases; defaults to the product's own site. */
  origin?: string;
  /** A GitHub token, tried after the endpoint; defaults to the GITHUB_TOKEN environment variable. */
  token?: string;
}

/**
 * Latest release tag and link, at build time. Tries the site's own /captain/releases, then
 * GitHub when a token is available (never unauthenticated: 60 requests an hour per IP is what
 * made every build fall back), then the bundled snapshot. Never throws; never requests a
 * private (null) repo.
 */
export async function latestRelease(slug: Slug, opts: ReleaseOpts = {}): Promise<Release> {
  const p = PRODUCTS[slug];
  const line = (snapshot.releases as Record<string, { release: string }>)[slug]?.release ?? '';
  const [snapTag = '', snapDate = ''] = line.split(',').map((s) => s.trim());
  if (!p.repo) return { tag: snapTag, url: p.docs };
  const f = opts.fetch ?? globalThis.fetch;

  try {
    const res = await f(releasesUrl(slug, opts.origin), { signal: AbortSignal.timeout(TIMEOUT_MS), headers: { accept: 'application/json' } });
    if (res.ok) {
      const b: any = await res.json();
      if (valid(b?.tag, b?.url)) return { tag: b.tag, url: b.url, published_at: b.published_at ?? null };
    }
  } catch { /* next source */ }

  const token = opts.token ?? env('GITHUB_TOKEN');
  if (token) {
    try {
      const api = p.repo.replace('https://github.com/', 'https://api.github.com/repos/') + '/releases/latest';
      const res = await f(api, { signal: AbortSignal.timeout(TIMEOUT_MS), headers: { accept: 'application/vnd.github+json', authorization: `Bearer ${token}`, 'user-agent': 'sjl-frontdoor' } });
      if (res.ok) {
        const b: any = await res.json();
        if (valid(b?.tag_name, b?.html_url)) return { tag: b.tag_name, url: b.html_url, published_at: b.published_at ?? null };
      }
    } catch { /* the snapshot */ }
  }

  return { tag: snapTag, url: snapTag ? `${p.repo}/releases/tag/${encodeURIComponent(snapTag)}` : `${p.repo}/releases`, published_at: /^\d{4}-\d{2}-\d{2}$/.test(snapDate) ? snapDate : null };
}

// One lookup per product per build: the bar, the header and the footer all show the version.
const memo = new Map<Slug, Promise<Release>>();
export const releaseOf = (slug: Slug): Promise<Release> => {
  let r = memo.get(slug);
  if (!r) memo.set(slug, (r = latestRelease(slug)));
  return r;
};
