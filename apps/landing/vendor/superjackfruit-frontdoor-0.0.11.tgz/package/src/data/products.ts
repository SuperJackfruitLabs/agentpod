export type Slug = 'supermessage' | 'superpipeline' | 'superlibrary' | 'superwitness' | 'agentpod' | 'salaam';
/** A site that wears the frame: a product, or the lab's own site (never in ORDER). */
export type Site = Slug | 'lab';
export type Theme = 'light' | 'dark';

export interface Product {
  slug: Site;
  name: string;
  color: string;
  hi: string;
  url: string;
  docs: string;
  repo: string | null;
  /** The header's button: the hosted app's sign-in, or how to get the product. */
  app: { label: string; href: string } | null;
  street: 'main' | 'quarter';
  role: string;
  line: string;
  /** Port the product's site uses in local development (http://localhost:<port>/). */
  port: number;
  /** localStorage key the product's own site reads its theme from. */
  themeKey: string;
  /** The value that site expects for a suite-wide light/dark choice. */
  themeValue(t: Theme): string;
  /** The header's docs link label, and what Captain Jack's Ask field asks about. */
  docsLabel: string;
  about: string;
  /** The repo's licence (SPDX id), shown in the footer; null for the lab's own site. */
  licence: string | null;
}

const same = (t: Theme): string => t;
const org = 'https://github.com/SuperJackfruitLabs';

const make = (
  slug: Site, name: string, color: string, hi: string, domain: string, repo: string | null,
  street: Product['street'], role: string, line: string, port: number,
  themeKey = 'theme', themeValue: Product['themeValue'] = same,
): Product => ({
  slug, name, color, hi, url: `https://${domain}`, docs: `https://docs.${domain}`,
  repo: repo ? `${org}/${repo}` : null, app: null, street, role, line, port, themeKey, themeValue, docsLabel: 'Docs', about: name, licence: repo ? 'MIT' : null,
});

export const PRODUCTS: Record<Slug, Product> = {
  supermessage: make('supermessage', 'SuperMessage', '#8549ef', '#c3a6ff', 'supermessage.dev', 'supermessage', 'main', 'Talk', 'A Matrix client where agents are participants.', 4501, 'sm-theme'),
  superpipeline: make('superpipeline', 'SuperPipeline', '#ffc21a', '#ffd666', 'superpipeline.dev', 'superpipeline', 'main', 'Plan', 'A board agents work from, with gates for people.', 4502),
  superlibrary: make('superlibrary', 'SuperLibrary', '#f2704e', '#ffb59d', 'superlibrary.dev', 'superlibrary', 'main', 'Remember', 'The memory of the stack, labelled by outcome.', 4503),
  superwitness: make('superwitness', 'SuperWitness', '#0ea875', '#6ee7b7', 'superwitness.dev', 'superwitness', 'main', 'Witness', 'Every run, on the record.', 4504),
  agentpod: make('agentpod', 'AgentPod', '#2196f3', '#8cc8ff', 'agentpod.dev', 'agentpod', 'quarter', 'Machines', 'A console for the machines agents live on.', 4505),
  salaam: make('salaam', 'Salaam', '#f74783', '#ff9ec0', 'salaam.sh', 'salaam', 'quarter', 'Harness', 'The harness agents work in.', 4506, 'salaam-theme', (t) => (t === 'light' ? 'paper' : 'night')),
};

// The lab's own site: jackfruit amber (the site's suite accent), dark text on it; no docs site, no repo, no release.
export const LAB: Product = {
  ...make('lab', 'Super Jackfruit Labs', '#d98a1f', '#f2b45c', 'superjackfruit.com', null, 'main', 'Lab', 'Six tools for working with agents.', 4500),
  // the suite is the home page; the header offers the lab's notes, and the village as its button
  docs: 'https://superjackfruit.com/blog/', docsLabel: 'Lab notes', about: 'the lab', app: { label: 'Drive the village', href: '/village' },
};

export const SITES: Record<Site, Product> = { ...PRODUCTS, lab: LAB };

/** Text colour on the site colour. */
export const onColor = (p: Product): string => (p.slug === 'superpipeline' ? '#2c2a26' : p.slug === 'lab' ? '#1f1b18' : '#fff');

export const ORDER: Slug[] = ['supermessage', 'superpipeline', 'superlibrary', 'superwitness', 'agentpod', 'salaam'];

const LOCAL = /^(localhost|127\.0\.0\.1)$/;

/** Where a product lives, seen from `here`: its production URL, or its local port when `here` is localhost. */
export function hrefOf(slug: Slug, here?: { hostname: string }): string {
  const p = PRODUCTS[slug];
  return here && LOCAL.test(here.hostname) ? `http://localhost:${p.port}/` : p.url;
}

/** The product a URL belongs to (production origin, its www., or its local port), or null. */
export function slugOf(href: string): Slug | null {
  try {
    const u = new URL(href);
    return ORDER.find((s) => {
      const site = PRODUCTS[s].url;
      return u.origin === site || u.origin === site.replace('://', '://www.') || (LOCAL.test(u.hostname) && +u.port === PRODUCTS[s].port);
    }) ?? null;
  } catch { return null; }
}

PRODUCTS.superpipeline.app = { label: 'Sign in', href: 'https://app.superpipeline.dev' };
PRODUCTS.superlibrary.app = { label: 'Sign in', href: 'https://app.superlibrary.dev' };
PRODUCTS.superwitness.app = { label: 'Sign in', href: 'https://app.superwitness.dev' };
PRODUCTS.agentpod.app = { label: 'Sign in', href: 'https://console.agentpod.dev' };
PRODUCTS.supermessage.app = { label: 'Download', href: `${org}/supermessage/releases/latest` };
PRODUCTS.salaam.app = { label: 'Install', href: 'https://docs.salaam.sh/install/' };
PRODUCTS.salaam.licence = 'Apache-2.0';
