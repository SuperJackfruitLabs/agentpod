// A procedural background behind each product page, one motif per product, in three layers:
//   passive   always moving, quietly, whatever the visitor does
//   active    rare, faint events the motif starts by itself (background life, never a show)
//   reactive  the pointer's influence, which fades out once the pointer rests
//
//   supermessage   conversation: dots drift up like chatter; now and then one point sends a
//                  ring and another replies; the pointer sends rings as it moves
//   superpipeline  stages: dashes flow through lanes; a card crosses, waits at the gate
//                  column, then goes on; the flow bends around the pointer
//   superlibrary   catalogue: a grid of dots breathing in a slow wave; a shelf lights up
//                  dot by dot as something is filed; dots near the pointer lift
//   superwitness   witnesses: strokes that follow a wandering point and blink in a wave
//                  every so often; they turn to watch the pointer while it moves
//   agentpod       fleet: drifting nodes linked to their neighbours; a dispatch pulse runs
//                  along the links; nodes near the pointer link to it
//   salaam         lanterns: warm glows drifting and breathing; one rises and brightens now
//                  and then; they lean towards the pointer
//   lab            the suite: seven soft facets, the lab's amber and each product's hue,
//                  drifting slowly; now and then one brightens; they part around the pointer
//
// It sits behind the page (position:fixed, z-index:-1, no pointer events), follows the page's
// light or dark theme, pauses while the tab is hidden, draws one still frame for reduced
// motion, and caps its resolution so it stays cheap.
export function mountBackdrop({ product, color, theme, palette = [] }) {
  const canvas = document.createElement('canvas');
  canvas.setAttribute('aria-hidden', 'true');
  canvas.style.cssText = 'position:fixed;inset:0;width:100vw;height:100vh;z-index:-1;pointer-events:none';
  document.body.prepend(canvas);
  const ctx = canvas.getContext('2d');
  const still = matchMedia('(prefers-reduced-motion: reduce)');
  const [cr, cg, cb] = hex(color);
  let light = theme() === 'light';
  // On a light page the product colour is deepened (a third of the way to black) and drawn
  // stronger, or pale grounds wash it out; the neutral marks get darker ink to match.
  const deep = [cr, cg, cb].map((v) => Math.round(v * 0.68));
  const ink = (a) => (light ? `rgba(${deep[0]},${deep[1]},${deep[2]},${Math.min(1, Math.max(0, a) * 1.55)})` : `rgba(${cr},${cg},${cb},${Math.max(0, a)})`);
  // the same treatment for any colour of the palette (the lab draws every product's hue)
  const tint = (rgb) => (a) => (light ? `rgba(${rgb.map((v) => Math.round(v * 0.68)).join(',')},${Math.min(1, Math.max(0, a) * 1.55)})` : `rgba(${rgb.join(',')},${Math.max(0, a)})`);
  const soft = (a) => (light ? `rgba(35,28,22,${Math.min(1, a * 1.5)})` : `rgba(255,255,255,${a})`);

  let W = 0, H = 0, dpr = 1;
  // presence: 1 while the pointer moves, easing to 0 over ~2s once it rests.
  const pointer = { x: -9999, y: -9999, px: -9999, py: -9999, moved: -1e9, presence: 0 };
  function size() {
    dpr = Math.min(devicePixelRatio || 1, 1.5);
    W = innerWidth; H = innerHeight;
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    motif.resize?.();
  }
  const move = (x, y) => { pointer.px = pointer.x; pointer.py = pointer.y; pointer.x = x; pointer.y = y; pointer.moved = performance.now(); };
  addEventListener('pointermove', (e) => move(e.clientX, e.clientY), { passive: true });
  addEventListener('touchmove', (e) => e.touches[0] && move(e.touches[0].clientX, e.touches[0].clientY), { passive: true });
  document.addEventListener('pointerleave', () => (pointer.moved = -1e9));

  const rand = (a, b) => a + Math.random() * (b - a);
  const near = (x, y, r) => { const dx = x - pointer.x, dy = y - pointer.y; const d = Math.hypot(dx, dy); return { d, dx, dy, k: Math.max(0, 1 - d / r) * pointer.presence }; };
  const every = (ms) => { let next = performance.now() + rand(ms * 0.3, ms); return (t) => (t > next ? ((next = t + rand(ms * 0.7, ms * 1.3)), true) : false); };

  const MOTIFS = {
    supermessage() {
      // Water. A small height field (one cell per 8px) runs the classic two-buffer ripple
      // equation: every cell moves towards the average of its neighbours, the difference
      // becomes the next wave, and damping lets it die away. The pointer drags a soft wake
      // through it, now and then a "message" lands as a drop with a reply a moment later,
      // and only the surface's slope is drawn, as faint light and shade in the product
      // colour, scaled up smoothly so it reads as water, never as rings over the text.
      const CELL = 8, DAMP = 0.955;
      let gw = 0, gh = 0, a = null, b = null, img = null, off = null, octx = null;
      const talk = every(5200);
      const drops = [];
      const drop = (x, y, power, r = 2) => {
        const cx = Math.round(x / CELL), cy = Math.round(y / CELL);
        for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
          const gx = cx + dx, gy = cy + dy;
          if (gx < 1 || gy < 1 || gx >= gw - 1 || gy >= gh - 1) continue;
          const f = 1 - Math.hypot(dx, dy) / (r + 1);
          if (f > 0) a[gy * gw + gx] += power * f;
        }
      };
      return {
        resize() {
          gw = Math.ceil(W / CELL) + 2; gh = Math.ceil(H / CELL) + 2;
          a = new Float32Array(gw * gh); b = new Float32Array(gw * gh);
          off = document.createElement('canvas'); off.width = gw; off.height = gh;
          octx = off.getContext('2d'); img = octx.createImageData(gw, gh);
        },
        frame(t) {
          // the pointer's wake: strength follows speed, capped, so a fast sweep is a swell,
          // not a storm
          if (pointer.presence > 0.6 && pointer.px > -999) {
            const sp = Math.min(1, Math.hypot(pointer.x - pointer.px, pointer.y - pointer.py) / 30);
            if (sp > 0.02) drop(pointer.x, pointer.y, 80 * sp, 2);
            pointer.px = pointer.x; pointer.py = pointer.y;
          }
          // a message lands; a reply follows somewhere else
          if (talk(t)) {
            drops.push({ x: rand(W * 0.1, W * 0.9), y: rand(H * 0.15, H * 0.85), at: t, p: 90 });
            drops.push({ x: rand(W * 0.1, W * 0.9), y: rand(H * 0.15, H * 0.85), at: t + 900, p: 70 });
          }
          for (let i = drops.length - 1; i >= 0; i--) if (t >= drops[i].at) { drop(drops[i].x, drops[i].y, drops[i].p, 2); drops.splice(i, 1); }
          // one step of the wave equation
          for (let y = 1; y < gh - 1; y++) for (let x = 1; x < gw - 1; x++) {
            const k = y * gw + x;
            b[k] = ((a[k - 1] + a[k + 1] + a[k - gw] + a[k + gw]) / 2 - b[k]) * DAMP;
          }
          [a, b] = [b, a];
          // shade by slope: light where the surface faces up-left, shadow where it falls away
          const d = img.data, [r0, g0, b0] = light ? deep : [cr, cg, cb];
          for (let y = 1; y < gh - 1; y++) for (let x = 1; x < gw - 1; x++) {
            const k = y * gw + x, slope = (a[k - 1] - a[k + 1]) + (a[k - gw] - a[k + gw]);
            const v = Math.max(0, Math.min(1, Math.abs(slope) / 80));
            const o = k * 4;
            if (slope > 0) { d[o] = r0; d[o + 1] = g0; d[o + 2] = b0; } else { d[o] = light ? 255 : 0; d[o + 1] = light ? 255 : 0; d[o + 2] = light ? 255 : 0; }
            d[o + 3] = v * (slope > 0 ? (light ? 75 : 55) : (light ? 40 : 35));
          }
          octx.putImageData(img, 0, 0);
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.drawImage(off, -CELL, -CELL, gw * CELL, gh * CELL);
        },
      };
    },
    superpipeline() {
      const lanes = 9, parts = [], cards = [];
      const send = every(9000);
      const add = () => parts.push({ lane: Math.floor(rand(0, lanes)), x: rand(-50, W), v: rand(0.4, 1), off: 0 });
      return {
        resize() { parts.length = 0; for (let i = 0; i < 80; i++) add(); },
        frame(t) {
          const gap = H / (lanes + 1), gate = W * 0.68;
          for (let l = 1; l <= lanes; l++) { ctx.fillStyle = soft(0.03); ctx.fillRect(0, l * gap, W, 1); }
          ctx.fillStyle = ink(0.07); ctx.fillRect(gate, gap * 0.5, 2, H - gap);
          for (const p of parts) {
            const baseY = (p.lane + 1) * gap;
            const n = near(p.x, baseY + p.off, 160);
            p.off += ((n.k ? Math.sign(n.dy || 1) * n.k * 70 : 0) - p.off) * 0.08;
            p.x += p.v * (1 - n.k * 0.6);
            if (p.x > W + 20) { p.x = -20; p.lane = Math.floor(rand(0, lanes)); }
            ctx.fillStyle = ink(0.2 + n.k * 0.5); ctx.fillRect(p.x, baseY + p.off - 1.5, 14, 3);
          }
          // A card crosses its lane, waits at the gate for a person, then carries on.
          if (send(t)) cards.push({ lane: Math.floor(rand(0, lanes)), x: -60, held: 0 });
          for (let i = cards.length - 1; i >= 0; i--) {
            const c = cards[i], y = (c.lane + 1) * gap;
            if (c.x < gate - 46 || c.held > 140) c.x += 0.9; else c.held++;
            if (c.x > W + 60) { cards.splice(i, 1); continue; }
            const waiting = c.held > 0 && c.held <= 140;
            ctx.fillStyle = ink(waiting ? 0.2 + 0.04 * Math.sin(t / 600) : 0.16); ctx.fillRect(c.x, y - 5, 30, 10);
            if (waiting) { ctx.strokeStyle = ink(0.16); ctx.strokeRect(gate - 4, y - 10, 10, 20); }
          }
        },
      };
    },
    superlibrary() {
      const step = 28;
      const file = every(8000);
      let shelf = null;
      return {
        frame(t) {
          if (file(t)) shelf = { row: Math.floor(rand(1, H / step - 1)), start: t, from: Math.floor(rand(0, W / step / 2)) };
          for (let yi = 0, y = step / 2; y < H; y += step, yi++) {
            for (let xi = 0, x = step / 2; x < W; x += step, xi++) {
              const n = near(x, y, 170), lift = n.k * n.k;
              const wave = 0.5 + 0.5 * Math.sin(t / 1400 - x / 160 - y / 220);
              let lit = 0;
              if (shelf && yi === shelf.row && xi >= shelf.from) { const s = (t - shelf.start) / 90 - (xi - shelf.from); lit = s > 0 && s < 26 ? 0.4 * Math.sin((s / 26) * Math.PI) : 0; }
              const glow = Math.max(lift, lit * 0.8);
              ctx.fillStyle = glow > 0.02 ? ink(0.15 + glow * 0.65) : soft(0.045 + wave * 0.06);
              ctx.beginPath(); ctx.arc(x, y - lift * 6, 1 + wave * 0.35 + glow * 2.2, 0, 6.28); ctx.fill();
            }
          }
        },
      };
    },
    superwitness() {
      const step = 34;
      const blinkEvery = every(11000);
      let ax = 0, ay = 0, blink = null;
      return {
        frame(t) {
          const wx = W / 2 + Math.cos(t / 3100) * W * 0.32, wy = H / 2 + Math.sin(t / 2300) * H * 0.28;
          const p = pointer.presence;
          const tx = wx + (pointer.x - wx) * p, ty = wy + (pointer.y - wy) * p;
          ax += (tx - ax) * 0.06; ay += (ty - ay) * 0.06;
          // A blink travels across the field from a random side.
          if (blinkEvery(t)) blink = { t, x: rand(0, W) };
          ctx.lineCap = 'round';
          for (let y = step / 2; y < H; y += step) {
            for (let x = step / 2; x < W; x += step) {
              const a = Math.atan2(ay - y, ax - x), d = Math.hypot(ax - x, ay - y);
              const k = Math.max(0, 1 - d / 280);
              let open = 1;
              if (blink) { const s = (t - blink.t) / 900 - Math.abs(x - blink.x) / W; open = s > 0 && s < 0.25 ? Math.abs(Math.cos((s / 0.25) * Math.PI)) : 1; }
              const len = (5 + k * 6) * Math.max(0.12, open);
              ctx.strokeStyle = k > 0.02 ? ink(0.14 + k * 0.5) : soft(0.09);
              ctx.lineWidth = 1.3;
              ctx.beginPath(); ctx.moveTo(x - Math.cos(a) * len / 2, y - Math.sin(a) * len / 2); ctx.lineTo(x + Math.cos(a) * len / 2, y + Math.sin(a) * len / 2); ctx.stroke();
            }
          }
          if (blink && t - blink.t > 2200) blink = null;
        },
      };
    },
    agentpod() {
      const nodes = [], pulses = [];
      const dispatch = every(5500);
      return {
        resize() { nodes.length = 0; const n = Math.round((W * H) / 24000); for (let i = 0; i < n; i++) nodes.push({ x: rand(0, W), y: rand(0, H), vx: rand(-0.2, 0.2), vy: rand(-0.2, 0.2) }); },
        frame(t) {
          for (const p of nodes) { p.x += p.vx; p.y += p.vy; if (p.x < 0 || p.x > W) p.vx *= -1; if (p.y < 0 || p.y > H) p.vy *= -1; }
          // The fleet's own links, always faintly there.
          const links = [];
          for (let i = 0; i < nodes.length; i++) for (let j = i + 1; j < nodes.length; j++) {
            const a = nodes[i], b = nodes[j], d = Math.hypot(a.x - b.x, a.y - b.y);
            if (d < 110) { links.push([a, b]); ctx.strokeStyle = soft(0.05 * (1 - d / 110)); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
          }
          // A dispatch runs from node to node along the links.
          if (dispatch(t) && links.length) { const [a, b] = links[Math.floor(rand(0, links.length))]; pulses.push({ a, b, t, hops: 2 }); }
          for (let i = pulses.length - 1; i >= 0; i--) {
            const p = pulses[i], s = (t - p.t) / 1100;
            if (s >= 1) {
              const next = links.filter(([u, v]) => (u === p.b || v === p.b) && u !== p.a && v !== p.a);
              if (p.hops > 0 && next.length) { const [u, v] = next[Math.floor(rand(0, next.length))]; pulses[i] = { a: p.b, b: u === p.b ? v : u, t, hops: p.hops - 1 }; } else pulses.splice(i, 1);
              continue;
            }
            ctx.strokeStyle = ink(0.14); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(p.a.x, p.a.y); ctx.lineTo(p.b.x, p.b.y); ctx.stroke();
            ctx.fillStyle = ink(0.35); ctx.beginPath(); ctx.arc(p.a.x + (p.b.x - p.a.x) * s, p.a.y + (p.b.y - p.a.y) * s, 1.8, 0, 6.28); ctx.fill();
          }
          for (const a of nodes) {
            const n = near(a.x, a.y, 220);
            if (n.k > 0) { ctx.strokeStyle = ink(0.35 * n.k); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(pointer.x, pointer.y); ctx.stroke(); }
            ctx.fillStyle = n.k ? ink(0.3 + n.k * 0.6) : soft(0.14);
            ctx.beginPath(); ctx.arc(a.x, a.y, 1.6 + n.k * 1.6, 0, 6.28); ctx.fill();
          }
        },
      };
    },
    salaam() {
      const glows = [];
      const rise = every(10000);
      return {
        resize() { glows.length = 0; for (let i = 0; i < 12; i++) glows.push({ x: rand(0, W), y: rand(0, H), r: rand(60, 150), ph: rand(0, 6.28), vx: 0, vy: 0, lift: 0 }); },
        frame(t) {
          // Now and then one lantern brightens and rises a little before settling.
          if (rise(t)) glows[Math.floor(rand(0, glows.length))].lift = 0.45;
          for (const g of glows) {
            const n = near(g.x, g.y, 520);
            g.vx += (-n.dx / (n.d || 1)) * n.k * 0.05 + Math.cos(t / 4000 + g.ph) * 0.012;
            g.vy += (-n.dy / (n.d || 1)) * n.k * 0.05 + Math.sin(t / 5000 + g.ph) * 0.012 - g.lift * 0.03;
            g.vx *= 0.96; g.vy *= 0.96; g.x += g.vx; g.y += g.vy; g.lift *= 0.985;
            if (g.y < -g.r) g.y = H + g.r; if (g.y > H + g.r) g.y = -g.r; if (g.x < -g.r) g.x = W + g.r; if (g.x > W + g.r) g.x = -g.r;
            const pulse = 0.7 + 0.3 * Math.sin(t / 1600 + g.ph);
            const grad = ctx.createRadialGradient(g.x, g.y, 0, g.x, g.y, g.r * (1 + g.lift * 0.4));
            grad.addColorStop(0, ink(0.15 * pulse + n.k * 0.1 + g.lift * 0.18));
            grad.addColorStop(1, ink(0));
            ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(g.x, g.y, g.r * (1 + g.lift * 0.4), 0, 6.28); ctx.fill();
          }
        },
      };
    },
    lab() {
      // The salaam lanterns' physics, quieter, one hue each: the amber twice, every product once.
      const hues = [color, ...palette, color].map((h) => tint(hex(h)));
      const glows = [];
      const wake = every(12000);
      return {
        resize() { glows.length = 0; hues.forEach((ink, i) => glows.push({ ink, x: rand(0, W), y: rand(0, H), r: rand(120, 240), ph: i * 0.9, vx: 0, vy: 0, lift: 0 })); },
        frame(t) {
          if (wake(t)) glows[Math.floor(rand(0, glows.length))].lift = 0.4;
          for (const g of glows) {
            const n = near(g.x, g.y, 420);
            g.vx += (n.dx / (n.d || 1)) * n.k * 0.03 + Math.cos(t / 6000 + g.ph) * 0.008;
            g.vy += (n.dy / (n.d || 1)) * n.k * 0.03 + Math.sin(t / 7000 + g.ph) * 0.008;
            g.vx *= 0.96; g.vy *= 0.96; g.x += g.vx; g.y += g.vy; g.lift *= 0.985;
            if (g.y < -g.r) g.y = H + g.r; if (g.y > H + g.r) g.y = -g.r; if (g.x < -g.r) g.x = W + g.r; if (g.x > W + g.r) g.x = -g.r;
            const pulse = 0.75 + 0.25 * Math.sin(t / 2200 + g.ph);
            const grad = ctx.createRadialGradient(g.x, g.y, 0, g.x, g.y, g.r);
            grad.addColorStop(0, g.ink(0.09 * pulse + g.lift * 0.12));
            grad.addColorStop(1, g.ink(0));
            ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(g.x, g.y, g.r, 0, 6.28); ctx.fill();
          }
        },
      };
    },
  };
  const motif = (MOTIFS[product] ?? MOTIFS.superlibrary)();
  size();
  addEventListener('resize', size);

  let raf = 0;
  const draw = (t) => {
    const idle = t - pointer.moved;
    pointer.presence = idle < 400 ? 1 : Math.max(0, 1 - (idle - 400) / 1800);
    ctx.clearRect(0, 0, W, H);
    motif.frame(t);
  };
  const loop = (t) => { draw(t); raf = requestAnimationFrame(loop); };
  const start = () => { cancelAnimationFrame(raf); if (still.matches) draw(performance.now()); else raf = requestAnimationFrame(loop); };
  document.addEventListener('visibilitychange', () => (document.hidden ? cancelAnimationFrame(raf) : start()));
  still.addEventListener('change', start);
  start();
  return { setTheme(t) { light = t === 'light'; if (still.matches) draw(performance.now()); } };
}

function hex(h) { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
