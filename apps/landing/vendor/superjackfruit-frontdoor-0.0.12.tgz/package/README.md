# @superjackfruit/frontdoor 0.0.1

The Super Jackfruit Labs frame for Astro product sites (Astro 5 and 7): suite bar, product header, claims ("works on its own") and the suite footer, rendered into the page's HTML inside Declarative Shadow DOM so site CSS cannot reach it. It is complete without JavaScript; the client script only adds behaviour.

## Install

Vendored tarballs, like vibekit. In the site's `package.json`:

```json
"dependencies": {
  "@superjackfruit/frontdoor": "file:vendor/superjackfruit-frontdoor-0.0.1.tgz",
  "@superjackfruit/vibekit": "file:vendor/superjackfruit-vibekit-0.0.14.tgz"
}
```

vibekit is a peer dependency (`>=0.0.14 <0.1.0`), not bundled: a `file:` dependency inside a tarball does not resolve for consumers, and the site is meant to carry vibekit anyway. Astro is a peer (`>=5`).

## Use

```astro
---
import SuiteHead from '@superjackfruit/frontdoor/components/SuiteHead.astro';
import Frame from '@superjackfruit/frontdoor/components/Frame.astro';
---
<html lang="en">
  <head>
    ...
    <SuiteHead product="superlibrary" />
  </head>
  <body>
    <Frame product="superlibrary" cta={{ label: 'Get started', href: '/docs/install/' }}>
      <!-- the page body only -->
    </Frame>
  </body>
</html>
```

`product` is one of `supermessage`, `superpipeline`, `superlibrary`, `superwitness`, `agentpod`, `salaam`, `superdispatch`, `superexchange`. SuperDispatch and SuperExchange have no docs site yet: their header and footer link the README on GitHub, and llms.txt is the site's own (`https://<domain>/llms.txt`). `Frame` also takes optional `sections` and `links` (arrays of `{label, href}`) for the header nav and the footer: `links` (support, terms, an archive) sit in a small row beside the footer's closing line; a link with the same address or label as one the frame already gives (Docs, Releases, GitHub, llms.txt) is dropped. Other exports: `@superjackfruit/frontdoor/client`, `/data` (product registry), `/data/ledger.snapshot.json`, `/brand/*`.

`SuiteHead` goes in `<head>`: one small inline script sets the theme before first paint and handles the arriving doorway between products.

## What the site must remove

Its own header, footer and theme toggle (and any script that drives them). The frame owns all three. Keep the page's own `<main>` content inside `<Frame>`.

## The footer

Eight product tiles (logo, name, one line) in two headed groups, "Your work" and "Where agents live"; this product's tile carries a quiet outline in its colour (`aria-current="page"`), and products already visited a small tick (localStorage `sjl-seen`). Three headed link columns: this product (Docs, Releases with the current version, GitHub, llms.txt), the suite (every product, the village) and the lab (Super Jackfruit Labs, contact, the repo's licence). Then one line, "A Super Jackfruit Labs product · a solo lab · <licence>", the site's own `links` in a small row, and a small Ask Captain Jack button. No illustration, no animation. Tap targets are at least 44px; on a phone the tiles sit in two columns.

## Theme adapter

The frame writes the visitor's choice into the site's own storage and `data-theme`, so existing site CSS keeps working:

| Product | Storage key | Values |
| --- | --- | --- |
| supermessage | `sm-theme` | `light` / `dark` |
| salaam | `salaam-theme` | `paper` / `night` |
| the others | `theme` | `light` / `dark` |

## Captain Jack: the `/captain/*` route

The frame calls `/captain/...` on the site's own origin (same-origin, no CORS). The suite worker (`worker/`) must be routed at `/captain/*` on each product domain. Without it the Ask field answers with a pointer to the docs; the page itself is unaffected.

## Releases: `/captain/releases`

The same worker answers `GET /captain/releases/<product>` (one product) and `GET /captain/releases` (every product, under `releases`), on every product domain, with no new routes: it sits under the existing `/captain/*` route. Each release is `{ product, tag, url, published_at, source }`.

- The worker asks `api.github.com/repos/SuperJackfruitLabs/<repo>/releases/latest`, with the `GITHUB_TOKEN` secret when it is set (5,000 requests an hour instead of 60).
- Answers are kept in the edge cache (Cache API) for 10 minutes, and sent with `Cache-Control: public, max-age=600`.
- If GitHub fails, the last good answer is used (kept a week, `source: "stale"`), then the bundled ledger snapshot (`source: "snapshot"`); both are sent with `max-age=60`, so GitHub is tried again soon.
- Only the product slugs are accepted (anything else is a 404), so it cannot proxy other repositories. GET and HEAD only.

To deploy (operator): `cd worker && npx wrangler secret put GITHUB_TOKEN` (a fine-grained token with no permissions beyond public read is enough), then `npx wrangler deploy`.

## No JavaScript

Everything is server-rendered: bar, header, claims, footer, ledger-backed claims text. Without JS you lose the theme switch animation, the doorway, scroll reveals, Captain Jack's sheet (and the footer's Ask button, which stays hidden) and the footer's visited ticks; links and content remain.

## Build behaviour

At build time the frame tries, each with a 3-second timeout: the site's own `/captain/ledger.json` (the live claims ledger), and for the version its own `/captain/releases/<product>`, then GitHub's API only if `GITHUB_TOKEN` is set in the build environment. If they are unreachable it falls back to the bundled snapshot (`src/data/ledger.snapshot.json`), so a build never fails because of them; on a slow or offline network it can add a few seconds. The version is looked up once per build and shared by the suite bar, header and footer.

In the browser, the header and footer refresh the version from `/captain/releases/<product>` on the page's own origin (never api.github.com). Any failure is silent and the built value stays.

vibekit is a peer dependency (`>=0.0.14 <0.1.0`): the site installs it alongside this package, and `npm install` warns if the site's vibekit is outside that range. Tested on Astro 5 and Astro 7.

## Refreshing the release snapshot

`npm run releases` (from the repo root) rewrites the `release` line of each product in both snapshots, `packages/frame/src/data/ledger.snapshot.json` (the page's fallback) and `worker/src/ledger.json` (the worker's fallback and Captain Jack's release facts), from each repo's latest GitHub release. It uses `gh api` when gh is signed in, otherwise `GITHUB_TOKEN`; the token is never written anywhere. Only the `release` line changes: `contents` and `pinned` stay as the claims ledger has them. `npm run ledger` runs it after rebuilding the ledger, since the ledger's own table can lag the releases.

Packing (`prepack`) and the worker's `npm run deploy` run it with `--check`: they stop if a snapshot is behind, so run `npm run releases` and commit first.

## Packing and verifying

From the repo root: `npm pack -w packages/frame --pack-destination .` gives `superjackfruit-frontdoor-0.0.1.tgz` (gitignored). The package ships `src/` (components, client, data, brand SVGs, vendored rig and logo motion) and this README; tests, fixture and e2e are excluded. The fixture imports by path; to verify a tarball, point the fixture's imports at `@superjackfruit/frontdoor/components/*`, add the two `file:` dependencies above, `npm install` in `fixture`, run `npm run e2e -w @superjackfruit/frontdoor`, then delete `fixture/node_modules`. Do not set `"sideEffects": false`: it is what dropped the rig script once.

## Reviewing a page

`scripts/review/review.mjs` (repo root) screenshots any suite page under every vibe (Daylight, Paper, Studio, Quiet), both themes and both motion settings, at desktop 1440x900 and phone 390x844, and stitches one contact sheet per page. It prints the console errors and failed loads each setting saw, and `window.__fps` when the page sets it. Needs Chrome installed, like `scripts/og`:

```sh
node scripts/review/review.mjs http://127.0.0.1:4337/ --stops 0,#how,1 --time 19:30
```

Sheets land in `scripts/review/out/` (gitignored). Options and how each setting reaches the page: [docs/review.md](../../docs/review.md).
