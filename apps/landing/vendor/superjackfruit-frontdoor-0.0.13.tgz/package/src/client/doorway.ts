// Moving between products crosses origins, so no View Transition can carry the page across.
// Both sides draw the same doorway instead (the destination's logo and name on its glow): the
// leaving page fades it in (leaveTo), the arriving page raises it before first paint (early.js)
// and opens it once the page is ready (revealArrival). Nothing travels in the URL except the
// theme fragment. Ported from the prototype's frame.js go(), arrival block and prefetch.
import supermessage from '../brand/supermessage.svg?raw';
import superpipeline from '../brand/superpipeline.svg?raw';
import superlibrary from '../brand/superlibrary.svg?raw';
import superwitness from '../brand/superwitness.svg?raw';
import agentpod from '../brand/agentpod.svg?raw';
import salaam from '../brand/salaam.svg?raw';
import superdispatch from '../brand/superdispatch.svg?raw';
import superexchange from '../brand/superexchange.svg?raw';
import supertoolkit from '../brand/supertoolkit.svg?raw';
import lab from '../brand/lab.svg?raw';
import { hrefOf, PRODUCTS, slugOf, STATIC_MARK, type Site, type Slug } from '../data/products';
import { carryFragment } from './theme';

const MARKS: Record<Site, string> = { supermessage, superpipeline, superlibrary, superwitness, agentpod, salaam, superdispatch, superexchange, supertoolkit, lab };

interface Door {
  el: HTMLElement;
  mark: HTMLElement;
  failsafe?: ReturnType<typeof setTimeout>;
  fade(to: boolean, ms: number): Promise<unknown>;
  remove(): void;
}
interface Early { doorway(slug: Site, logo?: string): Door; arrival: Door | null; from: Site | null }
export const early = (): Early | null => (globalThis as { __sjlFrameEarly?: Early }).__sjlFrameEarly ?? null;

// ---- logo motion: the brand pack's bundle, loaded after first paint, never before ----
type Motion = { create(container: Element, slug: string): { play(): void } };
let motion: Promise<Motion | null> | null = null;
function loadMotion(): Promise<Motion | null> {
  motion ??= import('../vendor/logo-motion.js')
    .then(() => (globalThis as { SJLLogoMotion?: Motion }).SJLLogoMotion ?? null)
    .catch(() => null);
  return motion;
}
const afterPaint = (): Promise<void> => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 0)));

/** Replaces a doorway's static mark with the brand motion, if the motion bundle loads. */
async function animate(door: Door, slug: Slug): Promise<void> {
  if (STATIC_MARK.has(slug)) return;
  const m = await loadMotion();
  if (!m || !door.el.isConnected) return;
  try {
    const box = document.createElement('div');
    box.style.cssText = 'width:100%;height:100%';
    const logo = m.create(box, slug);
    door.mark.replaceChildren(box);
    logo.play();
  } catch { /* the static mark stays */ }
}

/** Fades in the destination's doorway over this page (260ms), then leaves for it. */
let leaving = false;
export async function leaveTo(slug: Slug): Promise<void> {
  if (leaving) return; // a second click while the doorway closes changes nothing
  leaving = true;
  try {
    await go(slug);
  } catch {
    leaving = false; // a failed leave must not lock every later click out
    location.href = hrefOf(slug, location) + carryFragment();
  }
}

async function go(slug: Slug): Promise<void> {
  const to = hrefOf(slug, location) + carryFragment();
  const e = early();
  if (!e) { location.href = to; return; }
  const door = e.doorway(slug, MARKS[slug]);
  void animate(door, slug);
  await door.fade(true, 260);
  location.href = to;
}

/** Opens the arriving doorway when fonts, load and the frame are ready, ≥650ms after navigation start, ≤1.4s. */
export function revealArrival(): void {
  const e = early();
  const door = e?.arrival;
  if (!door) return;
  // Whatever happens below (a synchronous throw, a rejected promise), the doorway comes down:
  // an opaque doorway left standing would hide the whole page.
  try {
    const here = slugOf(location.href);
    if (here) afterPaint().then(() => animate(door, here)).catch(() => {});
    const loaded = new Promise<void>((r) => (document.readyState === 'complete' ? r() : addEventListener('load', () => r(), { once: true })));
    // The frame's claims are rendered at build time: they are ready once the document is parsed.
    const frame = new Promise<void>((r) => (document.readyState === 'loading' ? addEventListener('DOMContentLoaded', () => r(), { once: true }) : r()));
    const idle = (): Promise<void> => new Promise((r) => ('requestIdleCallback' in window ? requestIdleCallback(() => r(), { timeout: 250 }) : setTimeout(r, 60)));
    // The logo's motion gets 650ms on its own, then keeps playing as the doorway fades.
    const beat = new Promise((r) => setTimeout(r, Math.max(0, 650 - performance.now())));
    const cap = new Promise((r) => setTimeout(r, Math.max(0, 1400 - performance.now())));
    Promise.race([Promise.all([document.fonts?.ready, loaded, frame, beat]).then(idle), cap])
      .then(() => door.fade(false, 450))
      .catch(() => {})
      .then(() => door.remove(), () => door.remove());
  } catch {
    door.remove();
  }
  clearTimeout(door.failsafe); // claimed only once the chain exists: the client owns the reveal (and its own 1.4s cap)
}

// Back from the next product: the page comes out of the back/forward cache with the doorway still standing.
function clearOnPageshow(): void {
  addEventListener('pageshow', (ev) => { if (ev.persisted) { leaving = false; document.getElementById('sjl-doorway')?.remove(); } });
}

const prefetched = new Set<Slug>();
function prefetch(slug: Slug): void {
  if (prefetched.has(slug)) return;
  prefetched.add(slug);
  const l = document.createElement('link');
  l.rel = 'prefetch';
  l.href = hrefOf(slug, location);
  document.head.append(l);
}

/** Product links under `root` (a[data-s]): prefetch on intent, leave through the doorway on click. */
export function prefetchOnIntent(root: ParentNode): void {
  const here = slugOf(location.href);
  root.querySelectorAll<HTMLAnchorElement>('a[data-s]').forEach((a) => {
    const slug = a.dataset.s as Slug;
    if (!PRODUCTS[slug] || slug === here) return;
    for (const ev of ['pointerenter', 'focus']) a.addEventListener(ev, () => prefetch(slug));
    a.addEventListener('click', (ev) => {
      if (ev.defaultPrevented || ev.button !== 0 || ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.altKey) return;
      ev.preventDefault();
      void leaveTo(slug);
    });
  });
}

/** Arrival reveal and bfcache cleanup; run once per page. */
export function mountDoorway(): void {
  revealArrival();
  clearOnPageshow();
}
