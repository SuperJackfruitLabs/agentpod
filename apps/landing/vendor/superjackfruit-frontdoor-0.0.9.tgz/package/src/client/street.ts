// The street (ported from the prototype's frame.js): visits remembered per site in
// localStorage 'sjl-seen' plus the product the visitor came from; the car parks at this
// product and, on a street click, flashes its lights then drives to the destination.
import type { Site, Slug } from '../data/products';

const SEEN = 'sjl-seen';
const still = (): boolean => matchMedia('(prefers-reduced-motion: reduce)').matches;
const wait = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms));

function remember(here: Site, from: Site | null): Set<string> {
  let seen: string[] = [];
  try { const v = JSON.parse(localStorage.getItem(SEEN) ?? '[]'); if (Array.isArray(v)) seen = v.filter((s) => typeof s === 'string'); } catch { /* none */ }
  const set = new Set([...seen, ...(from ? [from] : []), here]);
  try { localStorage.setItem(SEEN, JSON.stringify([...set])); } catch { /* private mode */ }
  return set;
}

export interface Street { drive(to: Slug): Promise<void> }

export function mountStreet(root: ShadowRoot, opts: { product: Site; from: Site | null }): Street {
  const seen = remember(opts.product, opts.from);
  root.querySelectorAll<HTMLElement>('a.house').forEach((h) => { if (seen.has(h.dataset.s ?? '')) h.classList.add('seen'); });
  const visits = root.getElementById('visits');
  const n = root.querySelectorAll('a.house.seen').length;
  if (visits) visits.textContent = `Your work on one street, the agents' on the other. Visited ${n} of 6${n === 6 ? ' — the whole town. Captain Jack noticed.' : '.'}`;

  // Street-only motion: windows light on hover (staggered), the car's flash.
  const s = document.createElement('style');
  s.textContent = `.house .win{transition:fill .3s ease}.house:hover .win{fill:#ffd88a}
:host([data-sjl-theme=light]) .house:hover .win{fill:color-mix(in srgb,var(--pc) 35%,#fff7d6)}
.car.flash{animation:sjl-flash .32s ease 2}@keyframes sjl-flash{50%{filter:brightness(1.8) drop-shadow(0 0 10px #fff6c0)}}`;
  root.append(s);
  root.querySelectorAll('a.house').forEach((h) => h.querySelectorAll<SVGElement>('.win').forEach((w, i) => (w.style.transitionDelay = `${(i % 9) * 30}ms`)));

  const car = root.getElementById('car');
  const scene = root.querySelector('.scene');
  const park = (slug: Site = opts.product): void => { // the lab has no house: the car stays put
    const h = root.querySelector(`a.house[data-s="${slug}"]`);
    if (!h || !car || !scene) return;
    const r = h.getBoundingClientRect(), sr = scene.getBoundingClientRect();
    car.style.left = `${r.left - sr.left + r.width / 2 - car.offsetWidth / 2}px`;
  };
  addEventListener('resize', () => park());
  let fontsReady: Promise<unknown> = Promise.resolve();
  try { fontsReady = document.fonts?.ready ?? fontsReady; } catch { /* no font API */ }
  fontsReady.catch(() => {}).then(() => setTimeout(() => park(), 60));
  park();

  return {
    // Only when the street is on screen: flash, then drive (1s), then the caller leaves.
    async drive(to) {
      if (!car || !scene || still()) return;
      const r = scene.getBoundingClientRect();
      if (r.top >= innerHeight || r.bottom <= 0) return;
      car.classList.remove('flash'); void car.offsetWidth; car.classList.add('flash');
      await wait(420);
      park(to);
      await wait(1040);
    },
  };
}
